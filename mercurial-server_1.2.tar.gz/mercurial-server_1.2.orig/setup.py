# WARNING: this file is NOT meant to be directly executed, but
# run from the Makefile.

from distutils.core import setup

setup(
    name="mercurial-server",
    description="Centralized Mercurial repository manager",
    url="http://www.lshift.net/mercurial-server.html",
    version="1.1", # FIXME: infer this
    package_dir = {'': 'src'},
    packages = ["mercurialserver"],
    requires = ["mercurial"], # FIXME: what version?
    scripts = ['src/hg-ssh', 'src/refresh-auth'],
    data_files = [
        ('init', [
            'src/init/hginit',
            'src/init/dot-mercurial-server',
            'src/init/hgadmin-hgrc'
        ]),
    ],
)
